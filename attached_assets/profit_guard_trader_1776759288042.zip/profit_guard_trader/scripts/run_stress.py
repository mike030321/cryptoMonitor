from __future__ import annotations
import argparse, json, multiprocessing as mp
from statistics import mean
from profit_guard.core.backtest import Backtester
from profit_guard.data.market import generate_market
SCENARIOS=['bull','bear','chop','crash','mixed']
def one_run(seed:int, bars:int)->dict[str,float|int|str]:
    scenario=SCENARIOS[seed % len(SCENARIOS)]; r=Backtester().run(generate_market(scenario,bars,seed))
    return {"seed":seed,"scenario":scenario,"return_pct":r.total_return_pct,"drawdown":r.max_drawdown_pct,"trades":r.trade_count,"win_rate":r.win_rate}
def main()->None:
    p=argparse.ArgumentParser(); p.add_argument('--runs',type=int,default=120); p.add_argument('--bars',type=int,default=1200); p.add_argument('--workers',type=int,default=8); a=p.parse_args()
    with mp.Pool(processes=a.workers) as pool: results=pool.starmap(one_run, [(seed,a.bars) for seed in range(1,a.runs+1)])
    returns=[x['return_pct'] for x in results]; dds=[x['drawdown'] for x in results]; trades=[x['trades'] for x in results]; passes=[x for x in results if x['return_pct']>0 and x['drawdown']<0.18]
    print(json.dumps({"runs":a.runs,"workers":a.workers,"avg_return_pct":round(mean(returns)*100,3),"min_return_pct":round(min(returns)*100,3),"max_return_pct":round(max(returns)*100,3),"avg_drawdown_pct":round(mean(dds)*100,3),"max_drawdown_pct":round(max(dds)*100,3),"avg_trades":round(mean(trades),2),"pass_rate_pct":round(len(passes)/len(results)*100,2)}, indent=2))
if __name__=='__main__': main()
