from __future__ import annotations
import argparse, json
from profit_guard.core.backtest import Backtester, small_grid_search
from profit_guard.data.market import generate_market
p=argparse.ArgumentParser(); p.add_argument('--scenario',default='mixed'); p.add_argument('--bars',type=int,default=1500); p.add_argument('--seed',type=int,default=7); p.add_argument('--optimize',action='store_true'); a=p.parse_args(); m=generate_market(a.scenario,a.bars,a.seed)
if a.optimize: print(json.dumps(small_grid_search(m), indent=2))
else:
    r=Backtester().run(m)
    print(json.dumps({"scenario":a.scenario,"bars":a.bars,"seed":a.seed,"final_equity":round(r.final_equity,2),"return_pct":round(r.total_return_pct*100,2),"drawdown_pct":round(r.max_drawdown_pct*100,2),"trade_count":r.trade_count,"win_rate":round(r.win_rate*100,2),"expectancy_bps":round(r.expectancy*10000,2),"sharpe_like":round(r.sharpe_like,3)}, indent=2))
