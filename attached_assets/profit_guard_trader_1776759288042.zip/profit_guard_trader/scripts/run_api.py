from profit_guard.api.server import run_server
if __name__=="__main__": run_server()
