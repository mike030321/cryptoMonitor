# Profit Guard Trader

Self-contained research-first trading engine with:
- long / short / flat decisions
- expected-edge gating after costs
- risk controls and drawdown halts
- backtesting, optimization, and stress testing
- tiny JSON API using the standard library

## Commands
```bash
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python scripts/run_backtest.py --scenario mixed --bars 1500
PYTHONPATH=src python scripts/run_stress.py --runs 120 --workers 8
PYTHONPATH=src python scripts/run_api.py
```
