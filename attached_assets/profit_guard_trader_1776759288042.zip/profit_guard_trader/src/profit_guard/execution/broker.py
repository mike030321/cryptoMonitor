from __future__ import annotations
from profit_guard.core.models import ClosedTrade, Position
from profit_guard.core.risk import RiskConfig
class PaperBroker:
    def __init__(self, risk:RiskConfig)->None: self.risk=risk
    def open_position(self, side:str, price:float, size_fraction:float, equity:float, stop_loss_pct:float, take_profit_pct:float, index:int)->Position:
        exec_price=price*(1.0+self.risk.slippage_per_side if side=='long' else 1.0-self.risk.slippage_per_side); notional=equity*size_fraction; size=notional/exec_price
        stop=exec_price*(1.0-stop_loss_pct if side=='long' else 1.0+stop_loss_pct); take=exec_price*(1.0+take_profit_pct if side=='long' else 1.0-take_profit_pct)
        return Position(side,exec_price,size,stop,take,index,self.risk.max_hold_bars,exec_price,exec_price)
    def maybe_close(self, pos:Position, high:float, low:float, close:float, index:int)->tuple[bool,float,str]:
        pos.highest_price=max(pos.highest_price,high); pos.lowest_price=min(pos.lowest_price,low)
        if pos.side=='long':
            if low<=pos.stop_price: return True,pos.stop_price,'stop_loss'
            if high>=pos.take_profit_price: return True,pos.take_profit_price,'take_profit'
        else:
            if high>=pos.stop_price: return True,pos.stop_price,'stop_loss'
            if low<=pos.take_profit_price: return True,pos.take_profit_price,'take_profit'
        if index-pos.entry_index>=pos.max_hold_bars: return True,close,'time_exit'
        return False,close,'hold'
    def close_position(self, pos:Position, exit_price:float, index:int, reason:str)->ClosedTrade:
        exec_price=exit_price*(1.0-self.risk.slippage_per_side if pos.side=='long' else 1.0+self.risk.slippage_per_side)
        gross=(exec_price-pos.entry_price)*pos.size
        if pos.side=='short': gross=(pos.entry_price-exec_price)*pos.size
        turnover=pos.entry_price*pos.size + exec_price*pos.size; fees=turnover*self.risk.fee_per_side; net=gross-fees; ret=net/(pos.entry_price*pos.size) if pos.entry_price>0 else 0.0
        return ClosedTrade(pos.side,pos.entry_price,exec_price,pos.size,pos.entry_index,index,gross,net,ret,reason)
