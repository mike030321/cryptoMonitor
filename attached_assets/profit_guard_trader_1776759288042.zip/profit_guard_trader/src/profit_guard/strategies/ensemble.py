from __future__ import annotations
from dataclasses import dataclass
from profit_guard.core.models import StrategyDecision
from profit_guard.core.utils import clamp
@dataclass(slots=True)
class StrategyConfig:
    long_momentum:float=0.009
    short_momentum:float=0.007
    r5_threshold:float=0.010
    flat_band:float=0.004
class EnsembleStrategy:
    def __init__(self, config:StrategyConfig|None=None)->None: self.config=config or StrategyConfig()
    def decide(self, f:dict[str,float])->StrategyDecision:
        m=f['momentum']; r1=f['r1']; r5=f['r5']; vol=f['volatility']; rp=f['range_pos']; vi=f['volume_impulse']; atr=f['atr_like']
        signal='flat'; edge=0.0; reasons=[]
        if m > self.config.long_momentum and r5 > self.config.r5_threshold and rp > 0.60 and vol < 0.012:
            signal='long'; edge = 0.45*m + 0.45*r5 + 0.0008*max(0.0,vi-1.0); reasons=['trend_long']
        elif m < -self.config.short_momentum and r5 < -self.config.r5_threshold and rp < 0.40:
            signal='short'; edge = 0.45*abs(m) + 0.45*abs(r5) + 0.0008*max(0.0,vi-1.0); reasons=['trend_short']
        elif vol > 0.016 and r1 < -0.010 and m < 0:
            signal='short'; edge = 0.006 + 0.20*vol + 0.20*abs(r1); reasons=['panic_short']
        confidence = clamp(0.5 + edge*110 + abs(m)*3 - vol*4, 0.0, 0.92)
        if edge < self.config.flat_band: signal='flat'
        stop_loss_pct = clamp(max(atr*1.8, vol*1.2, 0.004), 0.004, 0.03)
        take_profit_pct = clamp(max(edge*3.2, stop_loss_pct*1.8), 0.007, 0.10)
        return StrategyDecision(signal, confidence, edge, stop_loss_pct, take_profit_pct, f, reasons)
