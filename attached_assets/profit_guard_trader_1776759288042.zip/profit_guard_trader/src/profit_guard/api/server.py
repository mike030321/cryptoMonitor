from __future__ import annotations
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from profit_guard.core.backtest import Backtester, small_grid_search
from profit_guard.data.market import generate_market
class Handler(BaseHTTPRequestHandler):
    def _send(self, status:int, payload:dict)->None:
        raw=json.dumps(payload).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self): self._send(200,{"ok":True}) if self.path=='/health' else self._send(404,{"error":"not_found"})
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0')); body=self.rfile.read(n) if n else b'{}'; payload=json.loads(body.decode()) if body else {}
        if self.path=='/backtest':
            market=generate_market(payload.get('scenario','mixed'),int(payload.get('bars',1200)),int(payload.get('seed',7))); r=Backtester().run(market)
            self._send(200,{"final_equity":round(r.final_equity,2),"return_pct":round(r.total_return_pct,4),"drawdown_pct":round(r.max_drawdown_pct,4),"trade_count":r.trade_count,"win_rate":round(r.win_rate,4),"expectancy":round(r.expectancy,6),"sharpe_like":round(r.sharpe_like,4)})
        elif self.path=='/optimize':
            market=generate_market(payload.get('scenario','mixed'),int(payload.get('bars',1200)),int(payload.get('seed',7))); self._send(200,small_grid_search(market))
        else: self._send(404,{"error":"not_found"})
def run_server(host:str='127.0.0.1', port:int=8010)->None:
    server=HTTPServer((host,port),Handler); print(f'Profit Guard API listening on http://{host}:{port}'); server.serve_forever()
