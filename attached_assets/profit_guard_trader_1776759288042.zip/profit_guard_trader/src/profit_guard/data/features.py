from __future__ import annotations
from statistics import mean
from profit_guard.core.models import MarketBar
from profit_guard.core.utils import pct_change, rolling_mean, rolling_std, safe_div

def compute_features(bars:list[MarketBar], index:int)->dict[str,float]:
    closes=[b.close for b in bars[:index+1]]; highs=[b.high for b in bars[:index+1]]; lows=[b.low for b in bars[:index+1]]; vols=[b.volume for b in bars[:index+1]]; close=closes[-1]
    r1=pct_change(closes[-2],closes[-1]) if len(closes)>1 else 0.0; r5=pct_change(closes[-6],closes[-1]) if len(closes)>5 else r1
    ma_fast=rolling_mean(closes,10); ma_slow=rolling_mean(closes,30); vol=rolling_std([pct_change(a,b) for a,b in zip(closes[:-1],closes[1:])],20); avg_vol=rolling_mean(vols,20)
    recent_high=max(highs[-20:]) if len(highs)>=20 else max(highs); recent_low=min(lows[-20:]) if len(lows)>=20 else min(lows); range_pos=safe_div(close-recent_low,recent_high-recent_low,0.5)
    atr_like=rolling_mean([abs(pct_change(a,b)) for a,b in zip(closes[:-1],closes[1:])],14); momentum=safe_div(ma_fast-ma_slow,ma_slow,0.0)
    zscore=safe_div(close-mean(closes[-20:]),rolling_std(closes,20),0.0) if len(closes)>=20 else 0.0
    return {"close":close,"r1":r1,"r5":r5,"ma_fast":ma_fast,"ma_slow":ma_slow,"momentum":momentum,"volatility":vol,"volume_impulse":safe_div(vols[-1],avg_vol,1.0),"range_pos":range_pos,"atr_like":atr_like,"zscore":zscore}
