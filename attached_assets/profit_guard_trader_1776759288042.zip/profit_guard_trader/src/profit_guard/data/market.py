from __future__ import annotations
import random
from dataclasses import dataclass
from profit_guard.core.models import MarketBar
from profit_guard.core.utils import clamp
@dataclass(slots=True)
class ScenarioConfig:
    name:str; drift:float; volatility:float; crash_probability:float=0.0; crash_magnitude:float=0.0; mean_reversion:float=0.0; volume_base:float=1000.0
SCENARIOS={
"bull":[ScenarioConfig("bull",0.0009,0.006,mean_reversion=0.04)],
"bear":[ScenarioConfig("bear",-0.0009,0.007,mean_reversion=0.05)],
"chop":[ScenarioConfig("chop",0.0,0.009,mean_reversion=0.12)],
"crash":[ScenarioConfig("crash",-0.0010,0.016,0.02,0.06,0.02)],
"mixed":[ScenarioConfig("bull",0.0007,0.006,mean_reversion=0.04),ScenarioConfig("chop",0.0,0.01,mean_reversion=0.12),ScenarioConfig("bear",-0.0007,0.008,mean_reversion=0.06),ScenarioConfig("shock",-0.0005,0.018,0.015,0.045,0.03)]}
def generate_market(scenario:str="mixed", bars:int=1200, seed:int=7, start_price:float=100.0)->list[MarketBar]:
    rng=random.Random(seed); configs=SCENARIOS.get(scenario,SCENARIOS['mixed']); seg=max(1,bars//len(configs)); price=start_price; anchor=start_price; data=[]
    for i in range(bars):
        cfg=configs[min(i//seg,len(configs)-1)]
        revert=-(price-anchor)/anchor*cfg.mean_reversion
        shock=rng.gauss(cfg.drift+revert,cfg.volatility)
        if cfg.crash_probability and rng.random()<cfg.crash_probability: shock -= cfg.crash_magnitude*rng.uniform(0.6,1.4)
        new_close=max(1.0, price*(1.0+shock)); wiggle=abs(rng.gauss(0.0,cfg.volatility*0.55)); high=max(price,new_close)*(1.0+wiggle); low=min(price,new_close)*(1.0-wiggle)
        volume=cfg.volume_base*(1.0+abs(shock)*18+rng.random()*0.3); high=clamp(high,max(price,new_close),max(price,new_close)*1.2); low=clamp(low,min(price,new_close)*0.8,min(price,new_close))
        data.append(MarketBar(i,price,high,low,new_close,volume,cfg.name)); price=new_close
    return data
