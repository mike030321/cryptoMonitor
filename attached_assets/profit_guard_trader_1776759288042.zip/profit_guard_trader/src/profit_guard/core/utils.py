from __future__ import annotations
import math
from statistics import mean, pstdev

def clamp(v:float, lo:float, hi:float)->float: return max(lo, min(hi, v))
def safe_div(n:float,d:float, default:float=0.0)->float: return default if d==0 else n/d
def rolling_mean(values:list[float], window:int)->float: return mean(values if len(values)<window else values[-window:]) if values else 0.0
def rolling_std(values:list[float], window:int)->float:
    seg = values if len(values)<window else values[-window:]
    return pstdev(seg) if len(seg)>=2 else 0.0
def pct_change(a:float,b:float)->float: return 0.0 if a==0 else (b-a)/a
def sharpe_like(returns:list[float])->float:
    if len(returns)<2: return 0.0
    sigma=pstdev(returns)
    return 0.0 if sigma==0 else mean(returns)/sigma*math.sqrt(len(returns))
