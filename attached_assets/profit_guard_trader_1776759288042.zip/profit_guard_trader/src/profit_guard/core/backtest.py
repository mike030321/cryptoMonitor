from __future__ import annotations
from statistics import mean
from profit_guard.core.models import BacktestResult, ClosedTrade
from profit_guard.core.risk import PortfolioState, RiskConfig, RiskManager
from profit_guard.core.utils import sharpe_like
from profit_guard.data.features import compute_features
from profit_guard.execution.broker import PaperBroker
from profit_guard.strategies.ensemble import EnsembleStrategy, StrategyConfig
class Backtester:
    def __init__(self, strategy:EnsembleStrategy|None=None, risk_config:RiskConfig|None=None, initial_equity:float=10000.0)->None:
        self.strategy=strategy or EnsembleStrategy(); self.risk_config=risk_config or RiskConfig(); self.initial_equity=initial_equity; self.risk=RiskManager(self.risk_config); self.broker=PaperBroker(self.risk_config)
    def run(self, bars)->BacktestResult:
        equity=self.initial_equity; state=PortfolioState(equity,equity,equity); curve=[equity]; trades=[]; open_pos=None; flat_count=0; day_bucket=0
        for i,bar in enumerate(bars):
            if i<35: curve.append(equity); continue
            if i//96 != day_bucket: day_bucket=i//96; state.day_start_equity=equity
            if open_pos is not None:
                close_now, exit_price, reason=self.broker.maybe_close(open_pos,bar.high,bar.low,bar.close,i)
                if close_now:
                    trade=self.broker.close_position(open_pos,exit_price,i,reason); trades.append(trade); equity+=trade.net_pnl; open_pos=None; state.equity=equity; state.peak_equity=max(state.peak_equity,equity)
            if open_pos is None and self.risk.trading_allowed(state):
                d=self.strategy.decide(compute_features(bars,i))
                if d.signal=='flat': flat_count+=1
                else:
                    size=self.risk.position_size_fraction(d.confidence,d.stop_loss_pct,abs(d.expected_move))
                    if size>0: open_pos=self.broker.open_position(d.signal,bar.close,size,equity,d.stop_loss_pct,d.take_profit_pct,i)
                    else: flat_count+=1
            else: flat_count+=1
            state.equity=equity; state.peak_equity=max(state.peak_equity,equity); curve.append(equity)
        if open_pos is not None:
            last=bars[-1]; trade=self.broker.close_position(open_pos,last.close,last.index,'final_close'); trades.append(trade); equity+=trade.net_pnl; curve[-1]=equity
        rets=[t.return_pct for t in trades]; wins=[t for t in trades if t.net_pnl>0]
        return BacktestResult(equity,equity/self.initial_equity-1.0,self._max_dd(curve),trades,curve,len(wins)/len(trades) if trades else 0.0,mean(rets) if rets else 0.0,sharpe_like(rets),len(trades),flat_count,{})
    @staticmethod
    def _max_dd(curve:list[float])->float:
        peak=curve[0]; mdd=0.0
        for v in curve: peak=max(peak,v); mdd=max(mdd,(peak-v)/peak if peak>0 else 0.0)
        return mdd
def small_grid_search(bars)->dict[str,float|str]:
    candidates=[StrategyConfig(flat_band=0.0008),StrategyConfig(flat_band=0.0012),StrategyConfig(flat_band=0.0016)]
    best=None; best_score=float('-inf')
    for cfg in candidates:
        r=Backtester(strategy=EnsembleStrategy(cfg)).run(bars); score=r.total_return_pct-r.max_drawdown_pct*0.7+r.sharpe_like*0.02
        if score>best_score: best_score=score; best={"flat_band":cfg.flat_band,"score":score,"return_pct":r.total_return_pct,"drawdown":r.max_drawdown_pct}
    return best
