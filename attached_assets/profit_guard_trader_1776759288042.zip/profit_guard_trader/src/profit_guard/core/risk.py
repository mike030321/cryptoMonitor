from __future__ import annotations
from dataclasses import dataclass
from profit_guard.core.utils import clamp
@dataclass(slots=True)
class RiskConfig:
    risk_per_trade:float=0.0055; max_gross_exposure:float=0.8; daily_loss_limit:float=0.025; max_drawdown_limit:float=0.10; min_confidence:float=0.58; min_expected_edge:float=0.0022; fee_per_side:float=0.0006; slippage_per_side:float=0.0004; max_hold_bars:int=96
    @property
    def round_trip_cost(self)->float: return (self.fee_per_side+self.slippage_per_side)*2.0
@dataclass(slots=True)
class PortfolioState:
    equity:float; peak_equity:float; day_start_equity:float
    @property
    def drawdown_pct(self)->float: return 0.0 if self.peak_equity<=0 else max(0.0,(self.peak_equity-self.equity)/self.peak_equity)
    @property
    def day_loss_pct(self)->float: return 0.0 if self.day_start_equity<=0 else max(0.0,(self.day_start_equity-self.equity)/self.day_start_equity)
class RiskManager:
    def __init__(self, config:RiskConfig)->None: self.config=config
    def trading_allowed(self, state:PortfolioState)->bool: return state.drawdown_pct<self.config.max_drawdown_limit and state.day_loss_pct<self.config.daily_loss_limit
    def position_size_fraction(self, confidence:float, stop_loss_pct:float, expected_move:float)->float:
        if confidence<self.config.min_confidence: return 0.0
        gross_edge=expected_move-self.config.round_trip_cost
        if gross_edge<self.config.min_expected_edge: return 0.0
        stop_loss_pct=max(stop_loss_pct,0.001)
        size=self.config.risk_per_trade*(0.5+(confidence-self.config.min_confidence)*2.4)/stop_loss_pct
        size*=clamp(gross_edge/max(self.config.min_expected_edge,1e-6),0.4,2.0)
        return clamp(size,0.0,self.config.max_gross_exposure)
