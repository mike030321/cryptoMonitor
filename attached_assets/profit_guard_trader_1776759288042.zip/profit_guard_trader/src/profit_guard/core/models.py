from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal
Signal = Literal["long", "short", "flat"]
@dataclass(slots=True)
class MarketBar:
    index:int; open:float; high:float; low:float; close:float; volume:float; regime:str="unknown"
@dataclass(slots=True)
class StrategyDecision:
    signal:Signal; confidence:float; expected_move:float; stop_loss_pct:float; take_profit_pct:float; features:dict[str,float]=field(default_factory=dict); reasons:list[str]=field(default_factory=list)
@dataclass(slots=True)
class Position:
    side:Signal; entry_price:float; size:float; stop_price:float; take_profit_price:float; entry_index:int; max_hold_bars:int; highest_price:float; lowest_price:float
@dataclass(slots=True)
class ClosedTrade:
    side:Signal; entry_price:float; exit_price:float; size:float; entry_index:int; exit_index:int; gross_pnl:float; net_pnl:float; return_pct:float; reason:str
@dataclass(slots=True)
class BacktestResult:
    final_equity:float; total_return_pct:float; max_drawdown_pct:float; trades:list[ClosedTrade]; equity_curve:list[float]; win_rate:float; expectancy:float; sharpe_like:float; trade_count:int; flat_count:int; metadata:dict[str,float|int|str]=field(default_factory=dict)
