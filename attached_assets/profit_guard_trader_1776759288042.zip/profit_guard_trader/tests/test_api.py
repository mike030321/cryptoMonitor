import json, threading, time, unittest
from urllib.request import Request, urlopen
from profit_guard.api.server import run_server
class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.thread=threading.Thread(target=run_server, kwargs={'host':'127.0.0.1','port':8011}, daemon=True); cls.thread.start(); time.sleep(0.4)
    def test_health(self):
        with urlopen('http://127.0.0.1:8011/health') as r: payload=json.loads(r.read().decode())
        self.assertTrue(payload['ok'])
    def test_backtest(self):
        req=Request('http://127.0.0.1:8011/backtest', data=json.dumps({'scenario':'mixed','bars':400,'seed':3}).encode(), headers={'Content-Type':'application/json'}, method='POST')
        with urlopen(req) as r: payload=json.loads(r.read().decode())
        self.assertIn('final_equity',payload)
if __name__=='__main__': unittest.main()
