import unittest
from profit_guard.strategies.ensemble import EnsembleStrategy
class T(unittest.TestCase):
    def setUp(self): self.s=EnsembleStrategy()
    def test_flat(self): self.assertEqual(self.s.decide({"momentum":0.0,"r1":0.0,"r5":0.0,"volatility":0.005,"range_pos":0.5,"zscore":0.1,"volume_impulse":1.0,"atr_like":0.004}).signal,'flat')
    def test_long(self): self.assertEqual(self.s.decide({"momentum":0.015,"r1":0.004,"r5":0.013,"volatility":0.004,"range_pos":0.85,"zscore":0.5,"volume_impulse":1.2,"atr_like":0.006}).signal,'long')
    def test_short(self): self.assertEqual(self.s.decide({"momentum":-0.014,"r1":-0.006,"r5":-0.02,"volatility":0.012,"range_pos":0.1,"zscore":-0.4,"volume_impulse":1.25,"atr_like":0.011}).signal,'short')
if __name__=='__main__': unittest.main()
