import unittest
from profit_guard.core.backtest import Backtester, small_grid_search
from profit_guard.data.market import generate_market
class T(unittest.TestCase):
    def test_backtest(self):
        r=Backtester().run(generate_market('mixed',700,11)); self.assertGreater(r.trade_count,0); self.assertGreater(r.final_equity,0)
    def test_opt(self):
        best=small_grid_search(generate_market('mixed',500,19)); self.assertIn('flat_band',best)
    def test_shorts(self):
        r=Backtester().run(generate_market('bear',900,5)); self.assertGreater(sum(1 for t in r.trades if t.side=='short'),0)
if __name__=='__main__': unittest.main()
