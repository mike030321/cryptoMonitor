import unittest
from profit_guard.core.risk import PortfolioState, RiskConfig, RiskManager
class T(unittest.TestCase):
    def test_low_edge(self): self.assertEqual(RiskManager(RiskConfig()).position_size_fraction(0.7,0.01,0.001),0.0)
    def test_good_edge(self): self.assertGreater(RiskManager(RiskConfig()).position_size_fraction(0.72,0.01,0.012),0.0)
    def test_drawdown(self): self.assertFalse(RiskManager(RiskConfig(max_drawdown_limit=0.10)).trading_allowed(PortfolioState(8900,10000,10000)))
if __name__=='__main__': unittest.main()
