from __future__ import annotations

from collections import deque

from market_meta_brain.domain.types import GovernanceEpisode


class EpisodicMarketMemory:
    def __init__(self, capacity: int = 5000):
        self.capacity = capacity
        self._buffer: deque[GovernanceEpisode] = deque(maxlen=capacity)

    def push(self, episode: GovernanceEpisode) -> None:
        self._buffer.append(episode)

    def recent(self, n: int = 20) -> list[GovernanceEpisode]:
        return list(self._buffer)[-n:]

    def summarize_rewards(self, n: int = 50) -> dict[str, float]:
        items = self.recent(n)
        if not items:
            return {"count": 0.0, "avg_reward": 0.0}
        avg_reward = sum(x.reward for x in items) / len(items)
        return {"count": float(len(items)), "avg_reward": float(avg_reward)}

    def state_dict(self) -> dict:
        return {
            "capacity": self.capacity,
            "episodes": [episode.__dict__ for episode in self._buffer],
        }
